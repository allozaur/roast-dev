import{a as t}from"../chunks/entry.C-FhpiCR.js";export{t as start};
