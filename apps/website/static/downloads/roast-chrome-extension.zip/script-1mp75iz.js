
				{
					__sveltekit_1vnkuoh = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					const data = [{"type":"data","data":null,"uses":{}},null];

					Promise.all([
						import("./app/immutable/entry/start.CvfhIqqq.js"),
						import("./app/immutable/entry/app.D8-_ZML1.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 3],
							data,
							form: null,
							error: null
						});
					});
				}
			