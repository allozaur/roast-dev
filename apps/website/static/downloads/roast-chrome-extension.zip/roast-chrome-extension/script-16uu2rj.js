
				{
					__sveltekit_ctbc42 = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					const data = [{"type":"data","data":null,"uses":{}},null];

					Promise.all([
						import("./app/immutable/entry/start.cZVdXNWe.js"),
						import("./app/immutable/entry/app.3P8XSUp8.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 2],
							data,
							form: null,
							error: null
						});
					});
				}
			