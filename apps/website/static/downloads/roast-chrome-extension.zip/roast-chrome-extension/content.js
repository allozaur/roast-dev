function injectRoastButton() {
    var _a;
    var reviewButton = document.querySelector('.js-reviews-toggle');
    if (!reviewButton) {
        console.log('Review button not found');
        return;
    }
    var roastButton = document.createElement('button');
    roastButton.className = 'btn-secondary btn btn-sm js-roast-button';
    roastButton.innerHTML = 'Roast this PR 🔥';
    roastButton.setAttribute('data-view-component', 'true');
    roastButton.style.marginRight = '8px';
    (_a = reviewButton.parentNode) === null || _a === void 0 ? void 0 : _a.insertBefore(roastButton, reviewButton);
    roastButton.addEventListener('click', function (e) {
        e.preventDefault();
        // @ts-expect-error - Chrome specific
        chrome.runtime.sendMessage({ action: 'openPopup' });
    });
}
// Enhanced observer to handle GitHub's dynamic loading
function createObserver() {
    var callback = function (mutations) {
        for (var _i = 0, mutations_1 = mutations; _i < mutations_1.length; _i++) {
            var mutation = mutations_1[_i];
            if (mutation.addedNodes.length) {
                if (location.href.includes('/pull/') && location.href.includes('/files')) {
                    var reviewButton = document.querySelector('.js-reviews-toggle');
                    var roastButton = document.querySelector('.js-roast-button');
                    if (reviewButton && !roastButton) {
                        injectRoastButton();
                    }
                }
            }
        }
    };
    return new MutationObserver(callback);
}
var observer = createObserver();
observer.observe(document.body, { childList: true, subtree: true });
if (location.href.includes('/pull/') && location.href.includes('/files')) {
    // Try a few times to inject the button, as GitHub's UI might load async
    var attempts = [0, 500, 1000, 2000];
    attempts.forEach(function (delay) {
        setTimeout(function () {
            if (!document.querySelector('.js-roast-button')) {
                injectRoastButton();
            }
        }, delay);
    });
}
