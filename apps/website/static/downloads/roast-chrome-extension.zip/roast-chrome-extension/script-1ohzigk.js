
				{
					__sveltekit_q6xzvi = {
						base: new URL(".", location).pathname.slice(0, -1)
					};

					const element = document.currentScript.parentElement;

					const data = [{"type":"data","data":null,"uses":{}},null];

					Promise.all([
						import("./app/immutable/entry/start.YauQk9dR.js"),
						import("./app/immutable/entry/app.BvXxIGOn.js")
					]).then(([kit, app]) => {
						kit.start(app, element, {
							node_ids: [0, 2],
							data,
							form: null,
							error: null
						});
					});
				}
			