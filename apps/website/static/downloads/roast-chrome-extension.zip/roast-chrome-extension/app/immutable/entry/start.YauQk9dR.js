import{a as t}from"../chunks/entry.pl5nAMFc.js";export{t as start};
