import{a as t}from"../chunks/entry.C_xsZlhg.js";export{t as start};
