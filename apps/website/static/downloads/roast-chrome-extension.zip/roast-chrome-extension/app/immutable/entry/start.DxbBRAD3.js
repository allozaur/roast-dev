import{a as t}from"../chunks/entry.BTo4h8SP.js";export{t as start};
