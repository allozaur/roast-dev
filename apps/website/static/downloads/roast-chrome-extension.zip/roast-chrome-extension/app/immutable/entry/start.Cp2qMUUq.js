import{a as t}from"../chunks/entry.CrCx8zn6.js";export{t as start};
